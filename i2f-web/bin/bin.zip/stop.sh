PID=`cat goboot.pid`
kill -9 $PID
echo kill pid=$PID
